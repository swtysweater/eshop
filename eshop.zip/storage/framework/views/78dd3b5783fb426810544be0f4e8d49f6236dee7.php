<?php $__env->startSection('check'); ?>

<p><?php print_r($data)?></p>

<?php echo $__env->yieldSection(); ?><?php /**PATH /Users/dmitrii/Projects/eshop/resources/views/inc/check.blade.php ENDPATH**/ ?>
<?php $__env->startSection('hero'); ?>
<div class="jumbotron jumbotron-fluid">
    <img src="<?php echo e(asset('images/pumpkin.png')); ?>"/>
    <div class="container">
        <span>доставка продуктов</span>
    </div>
</div>
<?php echo $__env->yieldSection(); ?><?php /**PATH /Users/dmitrii/Projects/Sharaga/eshop/resources/views/inc/hero.blade.php ENDPATH**/ ?>
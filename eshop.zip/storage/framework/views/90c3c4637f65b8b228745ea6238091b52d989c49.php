<?php $__env->startSection('item'); ?>
<div class="card" id="product">
    <img class="card-img-top" src="<?php echo e(asset('images/products/'.$item['image'])); ?>" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title"><?php echo e($item['name']); ?></h5>
      <p class="card-text text-muted"><?php echo e($item['factoryName']); ?>, <?php echo e($item['country']); ?></p>
      <div class="d-flex flex-row justify-content-center btn-group">
        <a href="" class="btn btn-sm btn-outline-success">
        <i class="fas fa-shopping-basket"></i> <?php echo e($item['price']); ?> ₽
        </a>
        <a href="" class="btn btn-sm btn-outline-secondary">Подробнее</a>
      </div>
    </div>
  </div>
<?php echo $__env->yieldSection(); ?><?php /**PATH /Users/dmitrii/Projects/eshop/resources/views/inc/item.blade.php ENDPATH**/ ?>
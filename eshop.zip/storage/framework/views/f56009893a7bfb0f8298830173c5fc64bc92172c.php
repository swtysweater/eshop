<?php $__env->startSection('tablenames'); ?>

    <?php $__currentLoopData = $tablenames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="nav-item">
        <a href="<?php echo e(route('yacrudgTable', ['controller' => $table['tablename']])); ?>" class="nav-link">
            <i class="fas fa-circle nav-icon" style="font-size: 0.5rem;"></i>
            <p><?php echo e($table['name']); ?></p>
        </a>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::starter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dmitrii/Projects/eshop/vendor/swtysweater/yacrudg/src/resources/views/app.blade.php ENDPATH**/ ?>
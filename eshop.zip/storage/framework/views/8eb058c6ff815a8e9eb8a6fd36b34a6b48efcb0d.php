<?php $__env->startSection('page-title'); ?>
Каталог
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(Route::currentRouteName() == 'catalog'): ?>
<h1 class="my-4">Категории</h1>
<div class="text-center">
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card category d-inline-block" style="width: 18rem;">
    <a href="<?php echo e(route('category', ['id' => $category['id']])); ?>">
        <img class="card-img-top" src="<?php echo e(asset($category['img'])); ?>">
        <p><?php echo e($category['name']); ?></p>
    </a>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<?php if(Route::currentRouteName() == 'category'): ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card " id="product" style="width: 18rem; display: inline-block; margin: 1rem;">
    <img class="card-img-top" src="<?php echo e(asset('images/products/'.$el['image'])); ?>" alt="Card image cap">
    <div class="card-body">
        <h5 class="card-title"><?php echo e($el['name']); ?></h5>
        <p class="card-text text-muted"><?php echo e($el['factoryName']); ?>, <?php echo e($el['country']); ?></p>
        <div class="d-flex flex-col justify-content-center btn-group-vertical">
            <a id="add-item" class="btn btn-sm btn-outline-success">
                <i class="fas fa-shopping-basket"></i>
                <span><?php echo e($el['price']); ?> ₽</span>
                <input id="add-item-url" hidden type="text" value="<?php echo e(route('add-item', $el['id'])); ?>">
            </a>
            <a href="<?php echo e(asset(route('item', ['id'=>$el['id']]))); ?>" class="btn btn-sm btn-outline-secondary">Подробнее</a>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dmitrii/Projects/eshop/resources/views/catalog.blade.php ENDPATH**/ ?>
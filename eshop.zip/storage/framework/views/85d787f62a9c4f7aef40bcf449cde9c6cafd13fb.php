<?php $__env->startSection('page-title'); ?>
<?php echo e($data['name']); ?> - eshop
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="item col pd-4">

    <img class="row mx-auto py-5" style="height: 15rem; width: auto;" src="<?php echo e(asset('images/products/'.$data['image'])); ?>">

    <h1 class="text-center m-4"><?php echo e($data['name']); ?></h1>

        <div class="col">
            <div class="list-group list-group-horizontal text-center" id="list-tab" role="tablist">
            <a class="list-group-item list-group-item-action active" id="list-info-list" data-toggle="list" href="#list-info" role="tab" aria-controls="info">Информация</a>
            <a class="list-group-item list-group-item-action" id="list-nutrition-list" data-toggle="list" href="#list-nutrition" role="tab" aria-controls="nutrition">БЖУ</a>
            </div>
        </div>

        <div class="col">
            <div class="tab-content" id="nav-tabContent">
            <div class="tab-pane fade show active" id="list-info" role="tabpanel" aria-labelledby="list-info-list">
                <ul class="my-4 list-group">
                    <li class="list-group-item">Производитель: <?php echo e($data['factoryName']); ?></li>
                    <li class="list-group-item">Страна: <?php echo e($data['factoryName']); ?></li>
                </ul>
            </div>
            <div class="tab-pane fade" id="list-nutrition" role="tabpanel" aria-labelledby="list-nutrition-list">
                <ul class="my-4 list-group">
                    <li class="list-group-item">Белки: <?php echo e($data['protein']); ?></li>
                    <li class="list-group-item">Жиры: <?php echo e($data['fats']); ?></li>
                    <li class="list-group-item">Углеводы: <?php echo e($data['carbs']); ?></li>
                </ul>
            </div>
            </div>
        </div>

    <a class="row m-4 text-decoration-none" href="<?php echo e(route('add-item', $data['id'])); ?>">
        <button class="mx-auto px-5 rounded-pill btn btn-success">В корзину - <?php echo e($data['price']); ?>₽</button>
    </a>

</div>
<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dmitrii/Projects/eshop/resources/views/item.blade.php ENDPATH**/ ?>
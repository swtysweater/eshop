<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('page-title'); ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <?php if(View::hasSection('styles')): ?>
        <?php echo $__env->yieldContent('styles'); ?>
        <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <?php endif; ?>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
</head>
<body>

    <div class="mt-4 container text-center">

        <?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(auth()->guard()->check()): ?>
        <search img-path="<?php echo e(asset('images/products/')); ?>" item-path="<?php echo e(asset(route('item'))); ?>"></search>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    
    <script src="https://kit.fontawesome.com/6f2667af00.js" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>

<?php /**PATH /Users/dmitrii/Projects/eshop/resources/views/layouts/app.blade.php ENDPATH**/ ?>
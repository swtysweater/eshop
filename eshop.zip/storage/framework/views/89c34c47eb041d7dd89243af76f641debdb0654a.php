<?php $__env->startSection('footer'); ?>

<footer class="pt-4 my-md-5 pt-md-5 border-top">
  <div class="row">
    <div class="col-12 col-md">
      <p class="navbar-brand user-select-none">eshop</p>
      <small>© <?php echo e(date('Y')); ?></small>
    </div>
  </div>
</footer>

<?php echo $__env->yieldSection(); ?><?php /**PATH /Users/dmitrii/Projects/eshop/resources/views/inc/footer.blade.php ENDPATH**/ ?>
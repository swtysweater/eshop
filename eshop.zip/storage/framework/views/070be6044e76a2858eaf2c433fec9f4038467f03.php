<?php $__env->startSection('items'); ?>
<div class="row">
       
<?php for($i = 0; $i < 9; $i++): ?>
    <?php echo $__env->make('inc.item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endfor; ?>

</div><?php /**PATH /Users/dmitrii/Projects/Sharaga/eshop/resources/views/inc/items.blade.php ENDPATH**/ ?>
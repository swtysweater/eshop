<?php $__env->startSection('page-title'); ?>
Главная страница
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="jumbotron col my-5">
    <img class="row w-50 img-fluid mx-auto my-5" src="<?php echo e(asset('images/products/1.png')); ?>">
    <p class="logotext row text-center mx-auto my-5">Онлайн-магазин товаров</p>
</div>

<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dmitrii/Projects/eshop/resources/views/index.blade.php ENDPATH**/ ?>
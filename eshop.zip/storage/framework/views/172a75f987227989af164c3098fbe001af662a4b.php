<?php $__env->startSection('page-title'); ?>
Корзина - <?php echo e($total ?? '0'); ?> ₽
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1>Корзина</h1>

<ul class="list-group my-5">
<?php if(!empty($cartitems)): ?>
<?php
$count = 1;
?>
  <?php $__currentLoopData = $cartitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elkey => $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li class="list-group-item d-flex align-items-center">
    <span>
    <?php
      echo $count++;
    ?>
    </span>
    <div class="flex-grow-1">
      <span><?php echo e($el['item']['name']); ?></span>
      <span id="cart-item-price" class="badge badge-success badge-pill mx-2"><?php echo e($el['item']['price']); ?> ₽</span>
    </div>
    <a class="mx-2" id="cart-remove-item">
      <button type="button" class="btn btn-light">-</button>
      <input id="cart-remove-item-url" type="text" hidden value="<?php echo e(route('cart-remove', ['id' => $el['item']['id']])); ?>">
    </a>
    <span id="cart-item-qty" class="badge badge-primary badge-pill"><?php echo e($el['qty']); ?></span>
    <a class="mx-2" id="cart-add-item">
      <button type="button" class="btn btn-light">+</button>
      <input id="cart-add-item-url" type="text" hidden value="<?php echo e(route('cart-add', ['id' => $el['item']['id']])); ?>">
    </a>
    <a class="mx-2" id="cart-remove-all-items">
      <button type="button" class="btn btn-danger">Удалить</button>
      <input id="cart-remove-all-items-url" type="text" hidden value="<?php echo e(route('cart-remove-all', ['id' => $el['item']['id']])); ?>">
    </a>
  </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<form class="my-4" method="get" action="/cart/proceed">
<?php echo e(csrf_field()); ?>

  <div class="form-group">
  <label for="payment_method">Способ оплаты</label>
  <select class="form-control w-50 mx-auto" name="payment_method" id="payment_method">
    <?php
    
    foreach ($methods as $key=>$value)
    {
      if($value['name'] == 'Картой')
      {
        foreach($card as $item)
        {
          echo '<option value="'.$value['id'].'">Карта ****'.substr($item['name'], -4).' '.$item['expdate'].'</option>';
        }
      } else {
        if ($key == 0)
        {
          echo '<option selected value="'.$value['id'].'">'.$value['name'].'</option>';
        } else {
          echo '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
      }
    }
    
    ?>
  </select>
  </div>
  <a href="<?php echo e(route('cart-proceed')); ?>" class="buy-btn my-5 mx-auto">
    <button id="cart-total" type="submit" class="btn btn-success">Заказать - <?php echo e($total); ?> ₽</button>
  </a>
</form>
<?php else: ?>
<h3 class="text-center" style="opacity: 0.5;">Корзина пуста :(</h3>
<?php endif; ?>
</ul>
<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dmitrii/Projects/eshop/resources/views/cart.blade.php ENDPATH**/ ?>
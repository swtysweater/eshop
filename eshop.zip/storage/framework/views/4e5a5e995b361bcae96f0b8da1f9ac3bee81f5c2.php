<?php $__env->startSection('navbar'); ?>
<nav class="navbar navbar-expand-md navbar-light bg-light rounded-top">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                    eshop
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto text-center">
                      <li class="nav-item <?php echo e(Route::is('catalog') ? 'active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(route('home')); ?>">каталог<span class="sr-only">(current)</span></a>
                      </li>
                      <li class="nav-item <?php echo e(Route::is('about') ? 'active' : ''); ?>">
                        <a class="nav-link" href="#">о нас<span class="sr-only">(current)</span></a>
                      </li>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto text-center">
                        <li class="nav-item active-pink-4 mr-3">
                            <input class="form-control rounded-pill text-center" type="text" placeholder="поиск" aria-label="Search">
                        </li>
                            <li class="nav-item mr-3" id="themeSwitcher">
                                <a class="nav-link" href="#">
                                    <i class="fas fa-moon"></i>
                                </a>
                            </li>
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('вход')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('регистрация')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('выход')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
<?php echo $__env->yieldSection(); ?><?php /**PATH /Users/dmitrii/Projects/Sharaga/eshop/resources/views/inc/navbar.blade.php ENDPATH**/ ?>
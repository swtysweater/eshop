<?php $__env->startSection('content'); ?>

<?php if(!empty($response)): ?>
<div class="card card-primary">
    <div class="card-header">
    <h3 class="card-title"><?php echo e($controller.' > '.$id); ?></h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
    <form role="form" method="POST" action="<?php echo e(route('yacrudgUpdateSubmit', ['controller' => $controller, 'id' => $id])); ?>" enctype="multipart/content-data">
    <?php echo csrf_field(); ?>
    <div class="card-body">
        <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group">
        <label for="<?php echo e($key); ?>"><?php echo e($key); ?></label>
        <input type="text" class="form-control" id="<?php echo e($key); ?>" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- /.card-body -->

    <div class="card-footer">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
    </form>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('yacrudg::app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dmitrii/Projects/eshop/vendor/swtysweater/yacrudg/src/resources/views/update.blade.php ENDPATH**/ ?>
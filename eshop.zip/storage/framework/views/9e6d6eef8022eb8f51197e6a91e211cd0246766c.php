<?php $__env->startSection('content'); ?>
<div class="card card-primary">
    <div class="card-header">
    <h3 class="card-title">New CRUD</h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
    <form role="form" method="POST" action="<?php echo e(route('yacrudgNewSubmit')); ?>" enctype="multipart/content-data">
    <?php echo csrf_field(); ?>
    <div class="card-body">
        <div class="form-group">
        <label for="table">Table</label>
        <select name="table" class="form-control">
          <?php $__currentLoopData = $allTablenames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tables): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(isset($occupied)): ?>
              <?php if(!in_array($tables, $occupied)): ?>
                <option value="<?php echo e($tables); ?>"><?php echo e($tables); ?></option>
              <?php endif; ?>
            <?php else: ?>
              <option value="<?php echo e($tables); ?>"><?php echo e($tables); ?></option>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </div>
    </div>
    <!-- /.card-body -->

    <div class="card-footer">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('yacrudg::app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dmitrii/Projects/eshop/vendor/swtysweater/yacrudg/src/resources/views/new.blade.php ENDPATH**/ ?>
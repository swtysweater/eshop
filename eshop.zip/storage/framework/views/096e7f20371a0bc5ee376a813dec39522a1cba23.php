<?php $__env->startSection('item'); ?>
<div class="card" id="product">
    <img class="card-img-top" src="<?php echo e(asset('images/products/'.$data['image'])); ?>" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title"><?php echo e($data['name']); ?></h5>
      <p class="card-text text-muted"><?php echo e($data['factoryName']); ?>, <?php echo e($data['country']); ?></p>
      <div class="d-flex flex-row justify-content-center btn-group">
        <a href="" class="btn btn-sm btn-outline-success">
        <i class="fas fa-shopping-basket"></i> <?php echo e($data['price']); ?> ₽
        </a>
        <a href="" class="btn btn-sm btn-outline-secondary">Подробнее</a>
      </div>
    </div>
  </div>
<?php echo $__env->yieldSection(); ?><?php /**PATH /Users/dmitrii/Projects/Sharaga/eshop/resources/views/inc/item.blade.php ENDPATH**/ ?>
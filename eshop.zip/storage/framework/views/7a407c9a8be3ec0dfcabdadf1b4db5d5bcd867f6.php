<?php $__env->startSection('page-title'); ?>
Успешная оплата
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<i class="far fa-check-circle text-center my-5" style="width: 100%; font-size: 10rem; color: #3bdb66;"></i>
<h3 class="text-center">Заказ оформлен</h3>

<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dmitrii/Projects/eshop/resources/views/purchase.blade.php ENDPATH**/ ?>
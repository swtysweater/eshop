<?php $__env->startSection('page-title'); ?>
Главная страница
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<hero></hero>

<!--Carousel Wrapper-->
<div id="multi-item-example" class="carousel slide carousel-multi-item" data-ride="carousel">

  <!--Slides-->
  <div class="carousel-inner" role="listbox">

        <?php $__currentLoopData = $data->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($key == 0): ?>
            <div class="carousel-item active">
        <?php else: ?>
            <div class="carousel-item">
        <?php endif; ?>
            <div class="card-deck">
                <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" id="product">
                    <img class="card-img-top" src="<?php echo e(asset('images/products/'.$el['image'])); ?>" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($el['name']); ?></h5>
                        <p class="card-text text-muted"><?php echo e($el['factoryName']); ?>, <?php echo e($el['country']); ?></p>
                        <div class="d-flex flex-col justify-content-center btn-group-vertical">
                            <a id="add-item" class="btn btn-sm btn-outline-success">
                                <i class="fas fa-shopping-basket"></i>
                                <span><?php echo e($el['price']); ?> ₽</span>
                                <input id="add-item-url" hidden type="text" value="<?php echo e(route('add-item', $el['id'])); ?>">
                            </a>
                            <a href="<?php echo e(asset(route('item')) . '?id=' . $el['id']); ?>" class="btn btn-sm btn-outline-secondary">Подробнее</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>

  <ol class="carousel-indicators">
  <?php $__currentLoopData = $data->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($key == 0): ?>
        <li class="rounded-pill active" data-target="#multi-item-example" data-slide-to="<?php echo e($key); ?>" class="active"></li>
    <?php else: ?>
        <li class="rounded-pill" data-target="#multi-item-example" data-slide-to="<?php echo e($key); ?>" class="active"></li>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ol>

</div>

<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dmitrii/Projects/eshop/resources/views/home.blade.php ENDPATH**/ ?>
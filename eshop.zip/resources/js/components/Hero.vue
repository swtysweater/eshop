<template>
    <div class="jumbotron jumbotron-fluid">
        <img src="/images/pumpkin.png">
        <div class="container">
            <span>онлайн магазин</span>
        </div>
    </div>
</template>

<script>
export default {
    
}
</script>
@section('check')

<p><?php print_r($data)?></p>

@show
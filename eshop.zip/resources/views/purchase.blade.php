@extends('layouts.app')

@section('page-title')
Успешная оплата
@endsection

@section('content')
<i class="far fa-check-circle text-center my-5" style="width: 100%; font-size: 10rem; color: #3bdb66;"></i>
<h3 class="text-center">Заказ оформлен</h3>

@include('inc.footer')

@endsection
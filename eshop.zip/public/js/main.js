$(document).on('click', '#add-item', (e)=>{
    $(e.target).closest('#product').css('animation', 'fadeIn 0.5s ease-out forwards');
    setTimeout(()=>{$('#product').css('animation', 'none');}, 500);
    $.ajax({
        url: $(e.target).find('#add-item-url').val(),         /* Куда пойдет запрос */
        method: 'get',             /* Метод передачи (post или get) */
        success: function()
        {
            let result = 0;
            let price = $(e.target).find('span').text();
            let cartvalue = $('#cart-pill').text();
            result = Number(price.slice(0, -2)) + Number(cartvalue.slice(0, -2));
            $('#cart-pill').text(result + ' ₽');
            $('#cart-pill').css('animation', 'scaleUp 0.5s ease-out forwards');
            setTimeout(()=>{$('#cart-pill').css('animation', 'none');}, 500);
        }
    });
});

$(document).on('click', '#cart-remove-item', (e)=>{
    let qty = $(e.target).parent().parent().find('#cart-item-qty').text();
    let result = 0;
    let cartvalue = $('#cart-pill').text();
    price = $(e.target).parent().parent().find('#cart-item-price').text();
    $(e.target).parent().parent().find('#cart-item-qty').text(Number(qty-1));
    result = Number(cartvalue.slice(0, -2)) - Number(price.slice(0, -2));
    $('#cart-pill').text(result + ' ₽');
    if (result == 0) {
        $('#cart-total').parent().remove();
        $('.list-group').append('<h3 class="text-center" style="opacity: 0.5;">Корзина пуста :(</h3>');
    } else {
        $('#cart-total').text('Купить - '+result+' ₽');
    }
    $.ajax({
        url: $(e.target).parent().find('#cart-remove-item-url').val(),         /* Куда пойдет запрос */
        method: 'get'         /* Метод передачи (post или get) */
    });
    if(qty == '1')
    {
        $(e.target).closest('.list-group-item').remove();
    }
});
$(document).on('click', '#cart-add-item', (e)=>{
    let qty = $(e.target).parent().parent().find('#cart-item-qty').text();
    let result = 0;
    let cartvalue = $('#cart-pill').text();
    price = $(e.target).parent().parent().find('#cart-item-price').text();
    $(e.target).parent().parent().find('#cart-item-qty').text(Number(qty)+1);
    result = Number(cartvalue.slice(0, -2)) + Number(price.slice(0, -2));
    $('#cart-pill').text(result + ' ₽');
    $('#cart-total').text('Купить - '+result+' ₽');
    $.ajax({
        url: $(e.target).parent().find('#cart-add-item-url').val(),         /* Куда пойдет запрос */
        method: 'get'         /* Метод передачи (post или get) */
    });
});
$(document).on('click', '#cart-remove-all-items', (e)=>{
    let qty = $(e.target).parent().parent().find('#cart-item-qty').text();
    let result = 0;
    let cartvalue = $('#cart-pill').text();
    price = $(e.target).parent().parent().find('#cart-item-price').text();
    $(e.target).parent().parent().find('#cart-item-qty').text(Number(qty)+1);
    itemFullPrice = Number(price.slice(0, -2))*Number(qty);
    result = Number(cartvalue.slice(0, -2)) - Number(itemFullPrice);
    $('#cart-pill').text(result + ' ₽');
    $('#cart-total').text('Купить - '+result+' ₽');
    $(e.target).closest('.list-group-item').remove();
    $('.list-group').not(':has(li)').empty();
    $('.list-group').not(':has(li)').append('<h3 class="text-center" style="opacity: 0.5;">Корзина пуста :(</h3>');
    $.ajax({
        url: $(e.target).parent().find('#cart-remove-all-items-url').val(),         /* Куда пойдет запрос */
        method: 'get'         /* Метод передачи (post или get) */
    });
});